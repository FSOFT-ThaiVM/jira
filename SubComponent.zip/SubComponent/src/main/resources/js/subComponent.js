function loadSubComponentsTable() {
	var reqUrl = AJS.contextPath() + "/rest/fso-subcomponent-rest/1.0/table/all";
	var selfUrl = AJS.contextPath() + "/rest/fso-subcomponent-rest/1.0/table";

    var myRestfulTableInstance = new AJS.RestfulTable({
	    autoFocus: true,
	    el: jQuery("#fso-project-sub-components-table"),
	    allowReorder: true,
	    resources: {
	        all: reqUrl,
	        self: selfUrl
	    },
	    columns: [
	        {
	            id: "componentName",
	            header: "Component"
	        },
	        {
	            id: "name",
	            header: "Name"
	        },
	        {
	            id: "description",
	            header: "Desc"
	        }
	    ]
	});

    AJS.$.ajax({
        url: reqUrl,
        type: "GET",
        contentType: "application/json",
        success: function(data, status, msg) {
            console.log(data);
            console.log(status);
            console.log(msg);
            if(data.status && data.status == 400) {
                alert(data.response.errors.error);
            }
            myRestfulTableInstance.addRow(data, 1);
        },
        error: function(data, status, msg) {
            console.log(data);
            console.log(status);
            console.log(msg);
            alert("failure");
        }
    });
    jQuery("[name='componentName']").attr('id','componentName');

    jQuery('#componentName').textext({
        plugins : 'tags prompt focus autocomplete ajax arrow',
        tagsItems : [ 'Basic', 'JavaScript', 'PHP', 'Scala' ],
        prompt : 'Add one...',
        ajax : {
            url : reqUrl,
            dataType : 'json',
            contentType: "application/json",
            cacheResults : true
        }
    });
}    	

function getSCDetail(val) {
	var reqUrl = AJS.contextPath() + "/rest/fso-subcomponent-rest/1.0/detail/" + val;
	//var json = {id:val};
	
    AJS.$.ajax({
        url: reqUrl,
        //type: "POST",
        //data: JSON.stringify(json),
        type: "GET",
        contentType: "application/json",
        success: function(data, status, msg) {
        	//console.log(data);
        }, 
        complete: function(data) {
        	pushDataToSCDetailPopup(data);
        },
        error: function(data, status, msg) {
            console.log(data);
            console.log(status);
            console.log(msg);
            alert("Failure when getting Sub-Component detail!");
        }
    });
}

function buidExtMsgBlock(padLeftLine1, padLeftLine2, lbl1st, val1st, lbl2nd, val2nd, lbl3rd, val3rd, lbl4th, val4th) {
	var content = '';
	// wrapper
	content = content + '<div class=\"aui-message info\">';
	content = content + '<table width=\"100%\">';
	content = content + '<colgroup>';
	content = content + '<col width=\"28%\">';
	content = content + '<col width=\"36%\">';
	content = content + '<col width=\"36%\">';
	content = content + '</colgroup';
	content = content + '<tbody>';
	// line 1
	content = content + '<tr>';
	content = content + '<td colspan=\"3\" style=\"padding-left:' + padLeftLine1 + ';">';
	content = content + '<div class=\"field-group\" style=\"clear: both; margin: 0; padding: 0; display: block;\">';
	content = content + '<label for=\"plan-size\">' + lbl1st + '</label>';
	content = content + '<span class=\"field-value\" style=\"font-weight:normal;\">' + val1st + '</span>';
	content = content + '</div>';
	content = content + '</td>';
	content = content + '</tr>';
	// line 2
	content = content + '<tr>';
	// line 2 -> item 1
	content = content + '<td colspan=\"1\" style=\"padding-left:' + padLeftLine2 + ';\">';
	content = content + '<div class=\"field-group\" style=\"clear: both; margin: 0; padding: 0; display: block;\">';
	content = content + '<label for=\"plan-size\">' + lbl2nd + '</label>';
	content = content + '<span class=\"field-value\" style=\"font-weight:normal;\">' + val2nd + '</span>';
	content = content + '</div>';
	content = content + '</td>';
	// line 2 -> item 2
	content = content + '<td colspan=\"1\">';
	content = content + '<div class=\"field-group\">';
	content = content + '<label for=\"re-plan-size\">' + lbl3rd + '</label>';
	content = content + '<span class=\"field-value\" style=\"font-weight:normal;\">' + val3rd + '</span>';
	content = content + '</div>';
	content = content + '</td>';
	// line 2 -> item 3
	content = content + '<td colspan=\"1\">';
	content = content + '<div class=\"field-group\">';
	content = content + '<label for=\"actual-size\">' + lbl4th + '</label>';
	content = content + '<span class=\"field-value\" style=\"font-weight:normal;\">' + val4th + '</span>';
	content = content + '</div>';
	content = content + '</td>';
	content = content + '</tr>';
	
	content = content + '</tbody>';
	content = content + '</table>';
	content = content + '</div>';
	
	return content;
}

function pushDataToSCDetailPopup(data) {
	var jsob = JSON.parse(data.responseText);
	var content = '';
	content = '<form class=\"aui\" style=\"clear: both; margin-top: -5px;\">';
	content = content + '<div class=\"jira-dialog-content\">';
	
	// component
	content = content + '<div class=\"field-group\">';
	content = content + '<label for=\"components\">Component</label>';
	content = content + '<span class=\"field-value\" style=\"font-weight:normal;\">' + jsob.component + '</span>';
	content = content + '</div>';
	
	// type
	content = content + '<div class=\"field-group\">';
	content = content + '<label for=\"type\">Type</label>';
	content = content + '<span class=\"field-value\" style=\"font-weight:normal;\">' + jsob.type + '</span>';
	content = content + '</div>';
	
	// name
	content = content + '<div class=\"field-group\">';
	content = content + '<label for=\"name\">Name</label>';
	content = content + '<span class=\"field-value\" style=\"font-weight:normal;\">' + jsob.name + '</span>';
	content = content + '</div>';
	
	// status
	content = content + '<div class=\"field-group\">';
	content = content + '<label for=\"status\">Status</label>';
	content = content + '<span class=\"field-value\" style=\"font-weight:normal;\">' + jsob.status + '</span>';
	content = content + '</div>';
	
	// name
	content = content + '<div class=\"field-group\">';
	content = content + '<label for=\"description\">Description</label>';
	content = content + '<span class=\"field-value\" style=\"font-weight:normal;\">' + jsob.desc + '</span>';
	content = content + '</div>';
	
	// Size
	content = content + buidExtMsgBlock('55px', '52px', 'Size Unit', jsob.sizeUnit, 'Planned', jsob.planSize, 'Re-planned', jsob.rePlanSize, 'Actual', jsob.actualSize);
	// Release
	content = content + buidExtMsgBlock('83px', '51px', 'Release Date', '', 'Planned', jsob.planReleaseDate, 'Re-planned', jsob.rePlanReleaseDate, 'Actual', jsob.actualReleaseDate);
	// Effort
	content = content + buidExtMsgBlock('36px', '59px', 'Effort', '', 'Orign Est', jsob.originEst, 'Spent Time', jsob.spentTime, 'Remaining', jsob.remaining);
		
	content = content + '</div>';
	content = content + '</form>';
	
	showDetailPopup(800, 700, 'fso-subcomponent-detail', 'Sub-Component Name', content); 
}

function showDetailPopup(popupWidth, popupHeight, popupID, popupName, content) {
	var dialog = new AJS.Dialog({
	    width: popupWidth, 
	    height: popupHeight, 
	    id: popupID, 
	    closeOnOutsideClick: false
	});
	
	dialog.addHeader('Sub-Component Details');
	dialog.addPanel(popupName, "<p>" + content + "</p>", "panel-body");
	dialog.addLink("Cancel", function (dialog) {
	    dialog.hide();
	}, "#");
	dialog.addButtonPanel();
	dialog.show();
}