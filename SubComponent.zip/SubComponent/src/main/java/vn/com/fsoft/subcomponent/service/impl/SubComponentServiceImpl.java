/** 
 * Copyright 2013 (C) <FPT Software Limited Company> 
 *  
 * Created on : 13-09-2013 
 * Author     : PhuNV1 
 * 
 */
package vn.com.fsoft.subcomponent.service.impl;

import java.util.List;

import vn.com.fsoft.subcomponent.bean.SubComponent;
import vn.com.fsoft.subcomponent.dao.SubComponentDAO;
import vn.com.fsoft.subcomponent.service.SubComponentService;

public class SubComponentServiceImpl implements
		SubComponentService<SubComponent> {
	private SubComponentDAO<SubComponent> subComponentDAO;

	@Override
	public List<SubComponent> getAll() {
		return subComponentDAO.getAll();
	}

	@Override
	public SubComponent get(String id) {
		return subComponentDAO.get(id);
	}

	public void setSubComponentDAO(SubComponentDAO<SubComponent> subComponentDAO) {
		this.subComponentDAO = subComponentDAO;
	}

}
