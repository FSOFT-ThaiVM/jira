/** 
 * Copyright 2013 (C) <FPT Software Limited Company> 
 *  
 * Created on : 13-09-2013 
 * Author     : PhuNV1 
 * 
 */
package vn.com.fsoft.subcomponent.bean;

import net.java.ao.Entity;
import net.java.ao.schema.AutoIncrement;
import net.java.ao.schema.NotNull;
import net.java.ao.schema.PrimaryKey;
import net.java.ao.schema.Table;

@Table (value="SUB_COMPONENT_TYPE")
public interface SubComponentType extends Entity {
	@AutoIncrement
	@NotNull
	@PrimaryKey (value = "ID")
	long getId();
	
	String getName();
	void setName(String name);
	
	int getHasLOC();
	void setHasLOC();
	
	String getDescription();
	void setDescription(String description);
	
	String getCode();
	void setCode(String code);
	
	boolean isDisable();
	void setDisable(boolean disable);
	
	String getAppName();
	void setAppName(String appName);
	
	boolean isNewInit();
	void setNewInit(boolean newInit);
}
