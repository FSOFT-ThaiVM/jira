/** 
 * Copyright 2013 (C) <FPT Software Limited Company> 
 *  
 * Created on : 13-09-2013 
 * Author     : PhuNV1 
 * 
 */
package vn.com.fsoft.subcomponent.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utils {
	public static String formatDate(Date date, String pattern) {
		if (date == null) {
			return Constants.EMPTY;
		} else {
			return new SimpleDateFormat(pattern).format(date);
		}
	}

	public static Date formatDateToYYYYMMDD(String strDate) {
		if (null == strDate || strDate.equals(""))
			return null;

		SimpleDateFormat oldFormat = new SimpleDateFormat(
				Constants.DATE_FORMAT_DD_MMM_YYYY);
		SimpleDateFormat newFormat = new SimpleDateFormat(
				Constants.DATE_FORMAT_YYYY_MM_DD);
		Date oldDate;
		try {
			oldDate = oldFormat.parse(strDate);
			return newFormat.parse(newFormat.format(oldDate));
		} catch (ParseException e) {
		}
		return null;
	}

	public static String formatDateToDDMMMYYYY(final Date date) {
		if (date != null) {
			SimpleDateFormat dateFormat = new SimpleDateFormat(
					Constants.DATE_FORMAT_DD_MMM_YYYY);
			try {
				return dateFormat.format(date);
			} catch (IllegalArgumentException iae) {
				iae.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return Constants.EMPTY;
	}
}
