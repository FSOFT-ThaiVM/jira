/** 
 * Copyright 2013 (C) <FPT Software Limited Company> 
 *  
 * Created on : 13-09-2013 
 * Author     : PhuNV1 
 * 
 */
package vn.com.fsoft.subcomponent.service;

import java.util.List;

import com.atlassian.activeobjects.tx.Transactional;

@Transactional
public interface SubComponentService<T> {
	public List<T> getAll();
	
	public T get(String id);
}
