/** 
 * Copyright 2013 (C) <FPT Software Limited Company> 
 *  
 * Created on : 13-09-2013 
 * Author     : PhuNV1 
 * 
 */
package vn.com.fsoft.subcomponent.utils;

public class Constants {
	public static final String EMPTY = "";
	
	public static final String DATA_SOURCE = "defaultDS";
	
	/**
	 * Date formats 
	 */
	public static String DATE_FORMAT_DD_MMM_YYYY = "dd-MMM-yyyy";
	public static String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
	public static String DATE_FORMAT_MM_DD_YY = "MM/dd/yy";
	public static String DATE_FORMAT_DD_MM_YYYY = "dd-MM-yyyy";
}
