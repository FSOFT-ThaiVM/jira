/** 
 * Copyright 2013 (C) <FPT Software Limited Company> 
 *  
 * Created on : 13-09-2013 
 * Author     : PhuNV1 
 * 
 */
package vn.com.fsoft.subcomponent.dao.impl;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import net.java.ao.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.com.fsoft.subcomponent.bean.SubComponent;
import vn.com.fsoft.subcomponent.dao.SubComponentDAO;

import com.atlassian.activeobjects.external.ActiveObjects;

public class SubComponentDAOImpl implements SubComponentDAO<SubComponent> {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SubComponentDAOImpl.class);

	private ActiveObjects ao;

	@SuppressWarnings("deprecation")
	private static void initSubComponent(ActiveObjects activeObject) {
		SubComponent subCom;

		LOGGER.info("Prepare init Sub-Component...");

		subCom = activeObject.create(SubComponent.class);
		subCom.setComponentID(10000);
		subCom.setComponentName("Jira Handbook");
		subCom.setTypeID(3);
		subCom.setType("Training");
		subCom.setProjectID(10000);
		subCom.setProjectCode("FMS_TWIN");
		subCom.setName("Training Material");
		subCom.setDescription("Training Material Desc");
		subCom.setStatusID(3);
		subCom.setStatus("Open");
		subCom.setSizeUnit("Microsoft Word Page");
		subCom.setPlanSize(26);
		subCom.setInfo("Size: 26 Microsoft Word Page</br>Plan Release: 16-May-2013");
		subCom.setPlanReleaseDate(new Date(13, 4, 17));
		subCom.setRePlanReleaseDate(new Date(13, 4, 16));
		subCom.save();

		subCom = activeObject.create(SubComponent.class);
		subCom.setComponentID(10000);
		subCom.setComponentName("Jira Handbook");
		subCom.setTypeID(3);
		subCom.setType("Training");
		subCom.setProjectID(10000);
		subCom.setProjectCode("FMS_TWIN");
		subCom.setName("Training Record");
		subCom.setDescription("Training Record Desc");
		subCom.setStatusID(3);
		subCom.setStatus("Delivered");
		subCom.setSizeUnit("Microsoft Word Page");
		subCom.setPlanSize(33);
		subCom.setActualSize(38);
		subCom.setInfo("Size: 38 Microsoft Word Page</br>Actual Release: 16-May-2013");
		subCom.setPlanReleaseDate(new Date(13, 4, 17));
		subCom.setRePlanReleaseDate(new Date(13, 4, 15));
		subCom.setActualReleaseDate(new Date(17, 4, 16));
		subCom.save();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see vn.com.fsoft.subcomponent.dao.SubComponentDAO#getAll()
	 */
	@Override
	public List<SubComponent> getAll() {
		try {
			SubComponent[] subComponents = this.ao.find(SubComponent.class);

			if (subComponents.length > 0) {
				return Arrays.asList(subComponents);
			} else {
				SubComponentDAOImpl.initSubComponent(this.ao);

				subComponents = this.ao.find(SubComponent.class);

				LOGGER.info("Finished Init Sub-Com, subComponents.length: "
						+ subComponents.length);

				return Arrays.asList(subComponents);
			}
		} catch (Exception e) {
			LOGGER.error("--> Error in getAll(), details: \n");
			e.printStackTrace();
		}

		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see vn.com.fsoft.subcomponent.dao.SubComponentDAO#get(java.lang.String)
	 */
	@Override
	public SubComponent get(String id) {
		try {
			Query query = Query.select().where("id = ?", id);
			SubComponent[] subComponents = ao.find(SubComponent.class, query);

			if (subComponents.length > 0) {
				return subComponents[0];
			}
		} catch (Exception e) {
			LOGGER.error("Error in get(String id): " + id);
			e.printStackTrace();
		}

		return null;
	}

	public void setAo(ActiveObjects ao) {
		this.ao = ao;
	}

}
