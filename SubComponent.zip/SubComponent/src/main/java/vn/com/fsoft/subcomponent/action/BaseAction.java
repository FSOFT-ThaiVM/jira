/** 
 * Copyright 2013 (C) <Fsoft Limited Company> 
 *  
 * Created on : 13-09-2013 
 * Author     : PhuNV1 
 * 
 */
package vn.com.fsoft.subcomponent.action;

import com.atlassian.jira.web.action.JiraWebActionSupport;

public class BaseAction extends JiraWebActionSupport {
	private static final long serialVersionUID = 4301869049468499397L;
	
	protected static final String DETAIL = "detail";
	
	@Override
	public String doExecute() throws Exception {
		return SUCCESS;
	}
}
