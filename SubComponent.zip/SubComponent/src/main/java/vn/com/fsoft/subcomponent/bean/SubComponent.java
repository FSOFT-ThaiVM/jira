/** 
 * Copyright 2013 (C) <FPT Software Limited Company> 
 *  
 * Created on : 13-09-2013 
 * Author     : PhuNV1 
 * 
 */
package vn.com.fsoft.subcomponent.bean;

import java.util.Date;

import net.java.ao.Entity;
import net.java.ao.Preload;
import net.java.ao.schema.Table;

@Table(value="SUB_COMPONENT")
@Preload
public interface SubComponent extends Entity {
	long getComponentID(); 
	void setComponentID(long componentID);
	
	String getComponentName();
	void setComponentName(String componentName);
	
	long getProjectID(); 
	void setProjectID(long projectID);
	
	String getProjectCode();
	void setProjectCode(String projectCode);
	
	long getTypeID();
	void setTypeID(long typeID);
	
	String getType();
	void setType(String type);
	
	String getName();
	void setName(String name);
	
	String getDescription();
	void setDescription(String description);
	
	long getStatusID();
	void setStatusID(long statusID);
	
	String getStatus();
	void setStatus(String status);
	
	long getSizeUnitID();
	void setSizeUnitID(long sizeUnitID);
	
	String getSizeUnit();
	void setSizeUnit(String sizeUnit);
	
	double getPlanSize();
	void setPlanSize(double planSize);
	
	double getRePlanSize();
	void setRePlanSize(double rePlanSize);
	
	double getActualSize();
	void setActualSize(double actualSize);
	
	Date getPlanReleaseDate();
	void setPlanReleaseDate(Date planReleaseDate);
	
	Date getRePlanReleaseDate();
	void setRePlanReleaseDate(Date rePlanReleaseDate);
	
	Date getActualReleaseDate();
	void setActualReleaseDate(Date actualReleaseDate);
	
	String getInfo();
	void setInfo(String info);
}
