/** 
 * Copyright 2013 (C) <FPT Software Limited Company> 
 *  
 * Created on : 13-09-2013 
 * Author     : PhuNV1 
 * 
 */
package vn.com.fsoft.subcomponent.projectpanel;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.com.fsoft.subcomponent.bean.SubComponent;
import vn.com.fsoft.subcomponent.service.SubComponentService;

import com.atlassian.jira.plugin.projectpanel.ProjectTabPanel;
import com.atlassian.jira.plugin.projectpanel.impl.AbstractProjectTabPanel;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.project.ProjectManager;
import com.atlassian.jira.project.browse.BrowseContext;
import com.atlassian.jira.security.PermissionManager;
import com.atlassian.jira.security.Permissions.Permission;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;

public class SubComponentTabPanel extends AbstractProjectTabPanel implements
		ProjectTabPanel {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SubComponentTabPanel.class);

	private SubComponentService<SubComponent> subComponentService;
	private PermissionManager permissionManager;
	private UserManager userManager;
	private ProjectManager projectManager;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.atlassian.jira.plugin.browsepanel.TabPanel#showPanel(com.atlassian
	 * .jira.project.browse.BrowseContext)
	 */
	@Override
	public boolean showPanel(BrowseContext arg0) {
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.atlassian.jira.plugin.projectpanel.impl.AbstractProjectTabPanel#
	 * createVelocityParams(com.atlassian.jira.project.browse.BrowseContext)
	 */
	@Override
	protected Map<String, Object> createVelocityParams(BrowseContext ctx) {
		final Map<String, Object> params = super.createVelocityParams(ctx);
		final Project project;
		final ApplicationUser applicationUser;
		final long projectId = ctx.getProject().getId();
		final String userName = ctx.getUser().getName();
		boolean isAdminPermission = false;

		try {
			project = projectManager.getProjectObj(projectId);
			applicationUser = this.userManager.getUserByName(userName);
			isAdminPermission = this.permissionManager.hasPermission(
					Permission.PROJECT_ADMIN.getId(), project, applicationUser);

			LOGGER.error("--> isAdminPermission = " + isAdminPermission);

			List<SubComponent> listSubComponent = subComponentService.getAll();
			params.put("listSubComponent", listSubComponent);
		} catch (Exception e) {
			LOGGER.info(e.getMessage());
		}

		return params;
	}

	/**
	 * @param permissionManager
	 *            the permissionManager to set
	 */
	public void setPermissionManager(PermissionManager permissionManager) {
		this.permissionManager = permissionManager;
	}

	/**
	 * @param userManager
	 *            the userManager to set
	 */
	public void setUserManager(UserManager userManager) {
		this.userManager = userManager;
	}

	/**
	 * @param projectManager
	 *            the projectManager to set
	 */
	public void setProjectManager(ProjectManager projectManager) {
		this.projectManager = projectManager;
	}

	/**
	 * @param subComponentService
	 *            the subComponentService to set
	 */
	public void setSubComponentService(
			SubComponentService<SubComponent> subComponentService) {
		this.subComponentService = subComponentService;
	}

}
