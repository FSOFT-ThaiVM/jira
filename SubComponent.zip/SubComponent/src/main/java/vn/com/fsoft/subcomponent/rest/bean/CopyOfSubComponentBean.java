/** 
 * Copyright 2013 (C) <FPT Software Limited Company> 
 *  
 * Created on : 13-11-2013 
 * Author     : PhuNV1 
 * 
 */
package vn.com.fsoft.subcomponent.rest.bean;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.atlassian.jira.rest.bind.DateAdapter;

@XmlRootElement(name = "CopyOfSubComponentBean")
public class CopyOfSubComponentBean {

	static {

	}

	// Needed so that JAXB works.
	public CopyOfSubComponentBean() {
	}

	/**
	 * @param id
	 * @param projectID
	 * @param componentID
	 * @param typeID
	 * @param name
	 * @param description
	 * @param statusID
	 * @param sizeUnitID
	 * @param planSize
	 * @param rePlanSize
	 * @param actualSize
	 * @param planReleaseDate
	 * @param rePlanReleaseDate
	 * @param actualReleaseDate
	 */
	public CopyOfSubComponentBean(Long id, Long projectID, Long componentID,
			Long typeID, String name, String description, Long statusID,
			Long sizeUnitID, Double planSize, Double rePlanSize,
			Double actualSize, Date planReleaseDate, Date rePlanReleaseDate,
			Date actualReleaseDate) {
		this.id = id;
		this.projectID = projectID;
		this.componentID = componentID;
		this.typeID = typeID;
		this.name = name;
		this.description = description;
		this.statusID = statusID;
		this.sizeUnitID = sizeUnitID;
		this.planSize = planSize;
		this.rePlanSize = rePlanSize;
		this.actualSize = actualSize;
		this.planReleaseDate = planReleaseDate;
		this.rePlanReleaseDate = rePlanReleaseDate;
		this.actualReleaseDate = actualReleaseDate;
	}

	@XmlElement
	private Long id;

	@XmlElement
	private Long projectID;

	@XmlTransient
	private String componentName;

	@XmlElement
	private Long componentID;

	@XmlTransient
	private String projectCode;

	@XmlElement
	private Long typeID;

	@XmlTransient
	private String type;

	@XmlElement
	private String name;

	@XmlElement
	private String description;

	@XmlElement
	private Long statusID;

	@XmlTransient
	private String status;

	@XmlElement
	private Long sizeUnitID;

	@XmlTransient
	private String sizeUnit;

	@XmlElement
	private Double planSize;

	@XmlElement
	private Double rePlanSize;

	@XmlElement
	private Double actualSize;

	@XmlElement
	private Date planReleaseDate;

	@XmlElement
	private Date rePlanReleaseDate;

	@XmlElement
	private Date actualReleaseDate;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the projectID
	 */
	public Long getProjectID() {
		return projectID;
	}

	/**
	 * @param projectID
	 *            the projectID to set
	 */
	public void setProjectID(Long projectID) {
		this.projectID = projectID;
	}

	/**
	 * @return the componentName
	 */
	public String getComponentName() {
		return componentName;
	}

	/**
	 * @param componentName
	 *            the componentName to set
	 */
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

	/**
	 * @return the componentID
	 */
	public Long getComponentID() {
		return componentID;
	}

	/**
	 * @param componentID
	 *            the componentID to set
	 */
	public void setComponentID(Long componentID) {
		this.componentID = componentID;
	}

	/**
	 * @return the projectCode
	 */
	public String getProjectCode() {
		return projectCode;
	}

	/**
	 * @param projectCode
	 *            the projectCode to set
	 */
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}

	/**
	 * @return the typeID
	 */
	public Long getTypeID() {
		return typeID;
	}

	/**
	 * @param typeID
	 *            the typeID to set
	 */
	public void setTypeID(Long typeID) {
		this.typeID = typeID;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the statusID
	 */
	public Long getStatusID() {
		return statusID;
	}

	/**
	 * @param statusID
	 *            the statusID to set
	 */
	public void setStatusID(Long statusID) {
		this.statusID = statusID;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the sizeUnitID
	 */
	public Long getSizeUnitID() {
		return sizeUnitID;
	}

	/**
	 * @param sizeUnitID
	 *            the sizeUnitID to set
	 */
	public void setSizeUnitID(Long sizeUnitID) {
		this.sizeUnitID = sizeUnitID;
	}

	/**
	 * @return the sizeUnit
	 */
	public String getSizeUnit() {
		return sizeUnit;
	}

	/**
	 * @param sizeUnit
	 *            the sizeUnit to set
	 */
	public void setSizeUnit(String sizeUnit) {
		this.sizeUnit = sizeUnit;
	}

	/**
	 * @return the planSize
	 */
	public Double getPlanSize() {
		return planSize;
	}

	/**
	 * @param planSize
	 *            the planSize to set
	 */
	public void setPlanSize(Double planSize) {
		this.planSize = planSize;
	}

	/**
	 * @return the rePlanSize
	 */
	public Double getRePlanSize() {
		return rePlanSize;
	}

	/**
	 * @param rePlanSize
	 *            the rePlanSize to set
	 */
	public void setRePlanSize(Double rePlanSize) {
		this.rePlanSize = rePlanSize;
	}

	/**
	 * @return the actualSize
	 */
	public Double getActualSize() {
		return actualSize;
	}

	/**
	 * @param actualSize
	 *            the actualSize to set
	 */
	public void setActualSize(Double actualSize) {
		this.actualSize = actualSize;
	}

	/**
	 * @return the planReleaseDate
	 */
	@XmlElement
	@XmlJavaTypeAdapter(DateAdapter.class)
	public Date getPlanReleaseDate() {
		return planReleaseDate;
	}

	/**
	 * @param planReleaseDate
	 *            the planReleaseDate to set
	 */
	public void setPlanReleaseDate(Date planReleaseDate) {
		this.planReleaseDate = planReleaseDate;
	}

	/**
	 * @return the rePlanReleaseDate
	 */
	@XmlElement
	@XmlJavaTypeAdapter(DateAdapter.class)
	public Date getRePlanReleaseDate() {
		return rePlanReleaseDate;
	}

	/**
	 * @param tePlanReleaseDate
	 *            the rePlanReleaseDate to set
	 */
	public void setRePlanReleaseDate(Date rePlanReleaseDate) {
		this.rePlanReleaseDate = rePlanReleaseDate;
	}

	/**
	 * @return the actualReleaseDate
	 */
	@XmlElement
	@XmlJavaTypeAdapter(DateAdapter.class)
	public Date getActualReleaseDate() {
		return actualReleaseDate;
	}

	/**
	 * @param actualReleaseDate
	 *            the actualReleaseDate to set
	 */
	public void setActualReleaseDate(Date actualReleaseDate) {
		this.actualReleaseDate = actualReleaseDate;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this,
				ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
