/** 
 * Copyright 2013 (C) <FPT Software Limited Company> 
 *  
 * Created on : 13-09-2013 
 * Author     : PhuNV1 
 * 
 */
package vn.com.fsoft.subcomponent.vo;

import java.util.Date;

public class SubComponentVO {
	private long id;
	private long componentId;
	private long projectId;
	private long typeId;
	private String name;
	private String description;
	private long status;
	private long sizeUnit;
	private double planSize;
	private double rePlanSize;
	private double acutualSize;
	private Date planReleaseDate;
	private Date rePlanReleaseDate;
	private Date actualReleaseDate;
	private String info;
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
	/**
	 * @return the componentId
	 */
	public long getComponentId() {
		return componentId;
	}
	/**
	 * @param componentId the componentId to set
	 */
	public void setComponentId(long componentId) {
		this.componentId = componentId;
	}
	/**
	 * @return the projectId
	 */
	public long getProjectId() {
		return projectId;
	}
	/**
	 * @param projectId the projectId to set
	 */
	public void setProjectId(long projectId) {
		this.projectId = projectId;
	}
	/**
	 * @return the typeId
	 */
	public long getTypeId() {
		return typeId;
	}
	/**
	 * @param typeId the typeId to set
	 */
	public void setTypeId(long typeId) {
		this.typeId = typeId;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the status
	 */
	public long getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(long status) {
		this.status = status;
	}
	/**
	 * @return the sizeUnit
	 */
	public long getSizeUnit() {
		return sizeUnit;
	}
	/**
	 * @param sizeUnit the sizeUnit to set
	 */
	public void setSizeUnit(long sizeUnit) {
		this.sizeUnit = sizeUnit;
	}
	/**
	 * @return the planSize
	 */
	public double getPlanSize() {
		return planSize;
	}
	/**
	 * @param planSize the planSize to set
	 */
	public void setPlanSize(double planSize) {
		this.planSize = planSize;
	}
	/**
	 * @return the rePlanSize
	 */
	public double getRePlanSize() {
		return rePlanSize;
	}
	/**
	 * @param rePlanSize the rePlanSize to set
	 */
	public void setRePlanSize(double rePlanSize) {
		this.rePlanSize = rePlanSize;
	}
	/**
	 * @return the acutualSize
	 */
	public double getAcutualSize() {
		return acutualSize;
	}
	/**
	 * @param acutualSize the acutualSize to set
	 */
	public void setAcutualSize(double acutualSize) {
		this.acutualSize = acutualSize;
	}
	/**
	 * @return the planReleaseDate
	 */
	public Date getPlanReleaseDate() {
		return planReleaseDate;
	}
	/**
	 * @param planReleaseDate the planReleaseDate to set
	 */
	public void setPlanReleaseDate(Date planReleaseDate) {
		this.planReleaseDate = planReleaseDate;
	}
	/**
	 * @return the rePlanReleaseDate
	 */
	public Date getRePlanReleaseDate() {
		return rePlanReleaseDate;
	}
	/**
	 * @param rePlanReleaseDate the rePlanReleaseDate to set
	 */
	public void setRePlanReleaseDate(Date rePlanReleaseDate) {
		this.rePlanReleaseDate = rePlanReleaseDate;
	}
	/**
	 * @return the actualReleaseDate
	 */
	public Date getActualReleaseDate() {
		return actualReleaseDate;
	}
	/**
	 * @param actualReleaseDate the actualReleaseDate to set
	 */
	public void setActualReleaseDate(Date actualReleaseDate) {
		this.actualReleaseDate = actualReleaseDate;
	}
	/**
	 * @return the info
	 */
	public String getInfo() {
		return info;
	}
	/**
	 * @param info the info to set
	 */
	public void setInfo(String info) {
		this.info = info;
	}	
}
