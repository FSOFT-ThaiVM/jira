/** 
 * Copyright 2013 (C) <Fsoft Limited Company> 
 *  
 * Created on : 23-09-2013 
 * Author     : PhuNV1 
 * 
 */
package vn.com.fsoft.subcomponent.action;

import vn.com.fsoft.subcomponent.vo.SubComponentVO;
import webwork.action.PrepareAction;

public class SubComponentAction extends BaseAction implements PrepareAction {

	private static final long serialVersionUID = 579811059582571155L;

	private SubComponentVO subComponentVO;

	@Override
	public void prepare() throws Exception {
		this.subComponentVO = new SubComponentVO();
		this.subComponentVO.setComponentId(10000);
		this.subComponentVO.setTypeId(6);
		this.subComponentVO.setName("Audit Report");
	}

	public String doViewDetail() {
		return DETAIL;
	}

	/**
	 * @return the subComponentVO
	 */
	public SubComponentVO getSubComponentVO() {
		return subComponentVO;
	}
}
