/** 
 * Copyright 2013 (C) <FPT Software Limited Company> 
 *  
 * Created on : 13-09-2013 
 * Author     : PhuNV1 
 * 
 */
package vn.com.fsoft.subcomponent.dao;

import java.util.List;

public interface SubComponentDAO<T> {
	public List<T> getAll();
	
	public T get(String id);
}
