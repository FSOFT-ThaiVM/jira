/** 
 * Copyright 2013 (C) <FPT Software Limited Company> 
 *  
 * Created on : 13-11-2013 
 * Author     : PhuNV1 
 * 
 */
package vn.com.fsoft.subcomponent.rest.bean;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

@XmlRootElement(name = "SubComponentBean")
public class SubComponentBean {

	static {

	}

	// Needed so that JAXB works.
	public SubComponentBean() {
	}

	/**
	 * @param componentName
	 * @param name
	 * @param description
	 * @param id
	 */
	public SubComponentBean(Long id, String componentName, String name,
			String description) {
		this.id = id;
		this.componentName = componentName;
		this.name = name;
		this.description = description;
	}

	@XmlTransient
	private Long id;

	@XmlTransient
	private String componentName;

	@XmlElement
	private String name;

	@XmlElement
	private String description;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the componentName
	 */
	public String getComponentName() {
		return componentName;
	}

	/**
	 * @param componentName
	 *            the componentName to set
	 */
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/*
	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}

		final SubComponentBean other = (SubComponentBean) obj;

		if (this.id == null || (this.id != null && other.id == null)
				|| !this.id.equals(other.id)) {
			return false;
		}

		return true;
	}

	@Override
	public int hashCode() {
		int hash = 7;
		hash = 67 * hash + (this.id != null ? this.id.hashCode() : 0);
		hash = 67 * hash + (this.name != null ? this.name.hashCode() : 0);

		return hash;
	}
	*/
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this,
				ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
