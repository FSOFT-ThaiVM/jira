package vn.com.fsoft.subcomponent.rest;

import static com.atlassian.jira.rest.v1.util.CacheControl.NO_CACHE;

import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import vn.com.fsoft.subcomponent.bean.SubComponent;
import vn.com.fsoft.subcomponent.rest.bean.SubComponentBean;
import vn.com.fsoft.subcomponent.service.SubComponentService;
import vn.com.fsoft.subcomponent.utils.Utils;

import com.atlassian.jira.util.json.JSONException;
import com.atlassian.jira.util.json.JSONObject;
import com.atlassian.plugins.rest.common.security.AnonymousAllowed;

/**
 * URLS must follow this pattern
 * create  POST /urlOfRestResource
 * read  GET /urlOfRestResource[/id]
 * update  PUT /urlOfRestResource/id
 * delete  DELETE /urlOfRestResource/id
 */

@Path("/table")
@AnonymousAllowed
@Produces({ MediaType.APPLICATION_JSON })
public class SubComponentResource {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(SubComponentResource.class);

	private SubComponentService<SubComponent> subComponentService;
	
	@AnonymousAllowed
	@GET
	@Path("all")
	public Response getAll() {
		LOGGER.error("--> fetching all SC...");
		JSONObject json = new JSONObject();
		List<SubComponent> subComponents = this.subComponentService.getAll();
		SubComponentBean subComponentBean = new SubComponentBean(new Long(1), "componentName", "name", "description");
		
		if (CollectionUtils.isNotEmpty(subComponents)) {
			LOGGER.error("--> DONE with " + subComponents.size() + " SC");
			
			for (SubComponent subCom : subComponents) {
				
			}
		}
		
		try {
            json.put("id", "1");
			json.put("componentName", "componentName 1");
            json.put("description", "description 1");
            json.put("name", "name 1");
		} catch (JSONException e) {
			e.printStackTrace();
		}
		ResponseBuilder responseBuilder = Response.ok(json.toString()).cacheControl(NO_CACHE);
		return responseBuilder.build();
	}

    @AnonymousAllowed
    @POST
    public Response addRow(final Map<String, Object> data) {
        LOGGER.error("--> add row SC...");
        JSONObject json = new JSONObject();
        try {
            if(data.get("componentName") == null || data.get("description") == null || data.get("name") == null) {
                JSONObject errors = new JSONObject();
                JSONObject componentName = new JSONObject();
                componentName.put("componentName", "Please input componentName");
                errors.put("errors", componentName);
                ResponseBuilder responseBuilder = Response.status(400);
                LOGGER.error("--> bad request SC...");
                responseBuilder.entity(errors.toString());
                return responseBuilder.build();
            }
            String componentName = (String) data.get("componentName").toString();
            String description = (String) data.get("description").toString();
            String name = (String) data.get("name").toString();
            json.put("id", "2");
            json.put("componentName", componentName);
            json.put("description", description);
            json.put("name", name);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        ResponseBuilder responseBuilder = Response.ok(json.toString()).cacheControl(NO_CACHE);
        return responseBuilder.build();
    }
	
	@AnonymousAllowed
	@GET
	@Path("{id}")
	public Response getSubComponent(@PathParam("id") final String id) {
		LOGGER.error("--> oak! a LOST the way...");
		return null;
	}

	@PUT
	@Path("{id}")
	public Response updateVersion(@PathParam("id") final String id,final SubComponentBean bean) {
		LOGGER.error("--> preparing UPDATE SC...");
        LOGGER.error("--> id..." + id);
		JSONObject json = new JSONObject();
        LOGGER.error("--> componentName..." + bean.getComponentName());
        LOGGER.error("--> description..." + bean.getDescription());
        LOGGER.error("--> name..." + bean.getName());
		try {
            json.put("id", id);
            json.put("componentName", bean.getComponentName());
            json.put("description", bean.getDescription());
            json.put("name", bean.getName());
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		ResponseBuilder responseBuilder = Response.ok(json.toString()).cacheControl(NO_CACHE);
		return responseBuilder.build();
	}

    @AnonymousAllowed
	@DELETE
	@Path("{id}")
	public Response delete(@PathParam("id") final String id) {
		LOGGER.error("--> preparing DELETE SC...");

		ResponseBuilder responseBuilder = Response.ok(id).cacheControl(NO_CACHE);
		return responseBuilder.build();
	}

	@Path("detail/{id}")
	@AnonymousAllowed
	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	public Response getSubComponentDetail(@PathParam("id") final String id) {
		SubComponent subComponent = null;
		JSONObject json = new JSONObject();
		// String id = (String) data.get("id").toString();

		if (StringUtils.isNotBlank(id)) {
			subComponent = this.subComponentService.get(id);
		}

		if (subComponent != null) {
			LOGGER.info("SubComponent.name = " + subComponent.getName());

			try {
				json.put("component", subComponent.getComponentName());
				json.put("type", subComponent.getType());
				json.put("name", subComponent.getName());
				json.put("desc", subComponent.getDescription());
				json.put("status", subComponent.getStatus());
				json.put("sizeUnit", subComponent.getSizeUnit());
				json.put("planSize", subComponent.getPlanSize());
				json.put("rePlanSize", subComponent.getRePlanSize());
				json.put("actualSize", subComponent.getActualSize());
				json.put("planReleaseDate", Utils
						.formatDateToDDMMMYYYY(subComponent
								.getPlanReleaseDate()));
				json.put("rePlanReleaseDate", Utils
						.formatDateToDDMMMYYYY(subComponent
								.getRePlanReleaseDate()));
				json.put("actualReleaseDate", Utils
						.formatDateToDDMMMYYYY(subComponent
								.getActualReleaseDate()));
				json.put("originEst", "N/A");
				json.put("spentTime", "N/A");
				json.put("remaining", "N/A");
			} catch (JSONException e) {
				e.printStackTrace();
			}
		} else {
			throw new IllegalArgumentException("--> invalid Sub-Component ID: "
					+ id);
		}

		Response.ResponseBuilder responseBuilder = Response.ok(json.toString())
				.cacheControl(NO_CACHE);

		return responseBuilder.build();
	}

	/**
	 * @param subComponentService
	 *            the subComponentService to set
	 */
	public void setSubComponentService(
			SubComponentService<SubComponent> subComponentService) {
		this.subComponentService = subComponentService;
	}
}
