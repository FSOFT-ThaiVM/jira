DROP TABLE IF EXISTS `ao_6098bc_hello`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ao_6098bc_hello` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `MESSAGE` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ao_6098bc_hello`
--

LOCK TABLES `ao_6098bc_hello` WRITE;
/*!40000 ALTER TABLE `ao_6098bc_hello` DISABLE KEYS */;
INSERT INTO `ao_6098bc_hello` VALUES (1,'mr Phu');
/*!40000 ALTER TABLE `ao_6098bc_hello` ENABLE KEYS */;
UNLOCK TABLES;