package com.atlassian.plugin.tutorial;

import org.junit.Test;

public class AssignRoleTest
{
    @Test
    public void testSomething()
    {
    }
}
